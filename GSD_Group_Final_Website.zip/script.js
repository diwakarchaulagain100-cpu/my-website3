document.getElementById("inquiryForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const name = document.getElementById("name").value.trim();
  const status = document.getElementById("formStatus");

  if (!name) {
    status.textContent = "Please enter your name.";
    return;
  }

  status.textContent = "Thank you, " + name + "! Your inquiry has been prepared successfully.";
  this.reset();
});